# CLIPERO PRO — publicación gratuita

## Qué incluye
- Editor local de videos.
- Detección aproximada de picos de volumen.
- Recorte de 10 a 180 segundos.
- Exportación WebM en vertical, cuadrado u horizontal.
- Captura de pantalla para grabar una transmisión en vivo (si el navegador lo permite).
- PWA básica para instalarla desde el navegador.

## Publicar gratis con GitHub Pages
1. Crea o inicia sesión en https://github.com
2. Crea un repositorio público llamado `clipero-pro`.
3. Sube `index.html`, `manifest.webmanifest` y `sw.js` a la raíz del repositorio.
4. En el repositorio abre Settings → Pages.
5. En Build and deployment selecciona Deploy from a branch.
6. Selecciona `main` y `/ (root)` y pulsa Save.
7. GitHub te dará una dirección parecida a `https://TU-USUARIO.github.io/clipero-pro/`.

Después podrás abrir esa dirección desde el celular y usar “Añadir a pantalla de inicio”. Para aparecer en Google, registra la URL en Google Search Console y solicita indexación; no es inmediato ni garantizado.

## Límites importantes
- Pegar un enlace de Kick solo abre el canal; no descarga automáticamente VOD.
- Para editar VOD, carga un archivo de video que hayas descargado y tengas derecho a usar.
- La detección automática actual busca picos de volumen; no es IA semántica.
- La captura en vivo depende del navegador y del permiso de compartir audio.
- Los clips se exportan como WebM. No se garantiza MP4 en todos los navegadores.
- El procesamiento ocurre en el dispositivo; videos grandes requieren memoria y potencia suficientes.
